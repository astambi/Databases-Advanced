﻿namespace PhotoShare.Client.Core.Commands
{
    using System;

    public class MakeFriendsCommand
    {
        // MakeFriends <username1> <username2>
        public string Execute(string[] data)
        {
            throw new NotImplementedException();
        }
    }
}
