﻿namespace ProductsShop
{
    using System.Linq;
    using System.Xml.Linq;

    using Data;

    using Model;

    public class Application
    {
        public static void Main(string[] args)
        {
            ProductShopContext context = new ProductShopContext();

        }
    }
}
