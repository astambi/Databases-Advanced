﻿namespace PlanetHunters.Data.Dtos.Import
{
    public class PlanetImportDto
    {
        public string Name { get; set; }
        public float Mass { get; set; }
        public string StarSystem { get; set; }
    }
}
