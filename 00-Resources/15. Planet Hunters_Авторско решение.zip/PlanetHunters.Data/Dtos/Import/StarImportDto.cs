﻿namespace PlanetHunters.Data.Dtos.Import
{
    public class StarImportDto
    {
        public string Name { get; set; }
        public int Temperature { get; set; }
        public string StarSystem { get; set; }
    }
}
